package com.util;

public class HangulConversion {

}
