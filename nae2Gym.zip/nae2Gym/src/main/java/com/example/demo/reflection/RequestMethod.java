package com.example.demo.reflection;

public enum RequestMethod {
	GET, POST, PUT, DELETE;
}
