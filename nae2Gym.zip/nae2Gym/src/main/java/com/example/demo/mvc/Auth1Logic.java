package com.example.demo.mvc;

public class Auth1Logic {

}
